#include <SoftwareSerial.h>

// PushUpSense starter firmware
// HC-SR04: TRIG -> D4, ECHO -> D5
// AT-09 / HM-10 BLE: module TXD -> D10, module RXD <- D11
// Put a 1k + 2k voltage divider between Arduino D11 and BLE RXD.
SoftwareSerial BLE(10, 11); // Arduino RX, TX

const byte TRIG_PIN = 4;
const byte ECHO_PIN = 5;
const float DOWN_THRESHOLD_CM = 12.0; // Adjust after testing sensor placement
const float UP_THRESHOLD_CM   = 20.0; // Must be greater than DOWN threshold
const unsigned long REP_COOLDOWN_MS = 650;

long pushupCount = 0;
bool isDown = false;
unsigned long lastRepMs = 0;
String commandBuffer = "";

float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(3);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  unsigned long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if (duration == 0) return -1;
  return duration * 0.0343 / 2.0;
}

void sendCount() {
  BLE.print("COUNT:");
  BLE.println(pushupCount);
  Serial.print("COUNT:");
  Serial.println(pushupCount);
}

void handleBluetooth() {
  while (BLE.available()) {
    char c = (char)BLE.read();
    if (c == '\n' || c == '\r') {
      commandBuffer.trim();
      if (commandBuffer.equalsIgnoreCase("RESET")) {
        pushupCount = 0;
        isDown = false;
        sendCount();
        BLE.println("STATUS:Counter reset");
      }
      commandBuffer = "";
    } else if (commandBuffer.length() < 30) {
      commandBuffer += c;
    }
  }
}

void setup() {
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  Serial.begin(9600);
  BLE.begin(9600); // Typical HM-10 / AT-09 default; change if your module uses another baud rate
  BLE.println("READY");
  sendCount();
}

void loop() {
  handleBluetooth();

  float distance = readDistanceCm();
  if (distance > 0) {
    unsigned long now = millis();

    // A rep is counted once when the chest moves down, then returns up.
    if (!isDown && distance <= DOWN_THRESHOLD_CM && now - lastRepMs > REP_COOLDOWN_MS) {
      isDown = true;
    }

    if (isDown && distance >= UP_THRESHOLD_CM) {
      pushupCount++;
      isDown = false;
      lastRepMs = now;
      sendCount();
    }
  }
  delay(35);
}
